import { describe, test, expect } from "vitest";
import { k8sSerializer } from "./serializer";
import { DECLARABLE_MARKER } from "@intentius/chant/declarable";
import {
  defaultLabels,
  defaultAnnotations,
  DEFAULT_LABELS_MARKER,
  DEFAULT_ANNOTATIONS_MARKER,
} from "./default-labels";

// ── Mock helpers ────────────────────────────────────────────────────

function mockResource(
  entityType: string,
  props: Record<string, unknown>,
): any {
  return {
    [DECLARABLE_MARKER]: true,
    lexicon: "k8s",
    entityType,
    kind: "resource",
    props,
  };
}

function mockProperty(
  entityType: string,
  props: Record<string, unknown>,
): any {
  return {
    [DECLARABLE_MARKER]: true,
    lexicon: "k8s",
    entityType,
    kind: "property",
    props,
  };
}

// ── Tests ───────────────────────────────────────────────────────────

describe("k8sSerializer", () => {
  test("name is k8s", () => {
    expect(k8sSerializer.name).toBe("k8s");
  });

  test("rulePrefix is WK8", () => {
    expect(k8sSerializer.rulePrefix).toBe("WK8");
  });

  test("empty entities produce empty string", () => {
    const result = k8sSerializer.serialize(new Map());
    expect(result).toBe("");
  });

  test("single Deployment produces valid YAML with apiVersion/kind/metadata/spec", () => {
    const entities = new Map<string, any>();
    entities.set(
      "myApp",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "my-app", labels: { app: "my-app" } },
        spec: { replicas: 2 },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("apiVersion:");
    expect(result).toContain("kind: Deployment");
    expect(result).toContain("name: my-app");
    expect(result).toContain("replicas: 2");
  });

  test("metadata.name auto-generated from logical name (camelCase→kebab-case)", () => {
    const entities = new Map<string, any>();
    entities.set(
      "myWebApp",
      mockResource("K8s::Apps::Deployment", {
        spec: { replicas: 1 },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("name: my-web-app");
  });

  test("explicit metadata.name preserved", () => {
    const entities = new Map<string, any>();
    entities.set(
      "myApp",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "custom-name" },
        spec: { replicas: 1 },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("name: custom-name");
  });

  test("ConfigMap uses top-level data (specless type)", () => {
    const entities = new Map<string, any>();
    entities.set(
      "config",
      mockResource("K8s::Core::ConfigMap", {
        metadata: { name: "app-config" },
        data: { DB_HOST: "localhost" },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: ConfigMap");
    expect(result).toContain("DB_HOST: localhost");
    expect(result).not.toContain("spec:");
  });

  test("Secret uses top-level stringData (specless type)", () => {
    const entities = new Map<string, any>();
    entities.set(
      "secret",
      mockResource("K8s::Core::Secret", {
        metadata: { name: "app-secret" },
        stringData: { API_KEY: "secret123" },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: Secret");
    expect(result).toContain("API_KEY: secret123");
    expect(result).not.toContain("spec:");
  });

  test("Argo Application serializes with argoproj.io/v1alpha1 GVK", () => {
    const entities = new Map<string, any>();
    entities.set(
      "guestbook",
      mockResource("K8s::Argo::Application", {
        metadata: { name: "guestbook", namespace: "argocd" },
        spec: {
          project: "default",
          source: {
            repoURL: "https://github.com/argoproj/argocd-example-apps",
            path: "guestbook",
            targetRevision: "HEAD",
          },
          destination: { server: "https://kubernetes.default.svc", namespace: "guestbook" },
        },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("apiVersion: argoproj.io/v1alpha1");
    expect(result).toContain("kind: Application");
    expect(result).toContain("name: guestbook");
    expect(result).toContain("project: default");
  });

  test("Flux CRDs serialize with the correct per-group GVK", () => {
    const entities = new Map<string, any>();
    entities.set(
      "podinfoRepo",
      mockResource("K8s::Flux::GitRepository", {
        metadata: { name: "podinfo", namespace: "flux-system" },
        spec: { url: "https://github.com/stefanprodan/podinfo", interval: "1m" },
      }),
    );
    entities.set(
      "apps",
      mockResource("K8s::Flux::Kustomization", {
        metadata: { name: "apps", namespace: "flux-system" },
        spec: { interval: "10m", path: "./apps", prune: true },
      }),
    );
    entities.set(
      "podinfoRelease",
      mockResource("K8s::Flux::HelmRelease", {
        metadata: { name: "podinfo", namespace: "flux-system" },
        spec: { interval: "5m", chart: { spec: { chart: "podinfo" } } },
      }),
    );
    entities.set(
      "flux",
      mockResource("K8s::Flux::FluxInstance", {
        metadata: { name: "flux", namespace: "flux-system" },
        spec: { distribution: { version: "2.x", registry: "ghcr.io/fluxcd" } },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    // source-controller v1
    expect(result).toContain("apiVersion: source.toolkit.fluxcd.io/v1");
    expect(result).toContain("kind: GitRepository");
    // kustomize-controller v1
    expect(result).toContain("apiVersion: kustomize.toolkit.fluxcd.io/v1");
    expect(result).toContain("kind: Kustomization");
    // helm-controller — the one on v2, not v1
    expect(result).toContain("apiVersion: helm.toolkit.fluxcd.io/v2");
    expect(result).toContain("kind: HelmRelease");
    // Flux Operator v1
    expect(result).toContain("apiVersion: fluxcd.controlplane.io/v1");
    expect(result).toContain("kind: FluxInstance");
  });

  test("Namespace is specless type", () => {
    const entities = new Map<string, any>();
    entities.set(
      "myNs",
      mockResource("K8s::Core::Namespace", {
        metadata: { name: "my-namespace" },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: Namespace");
    expect(result).toContain("name: my-namespace");
    expect(result).not.toContain("spec:");
  });

  test("ClusterRole is specless type", () => {
    const entities = new Map<string, any>();
    entities.set(
      "viewRole",
      mockResource("K8s::Rbac::ClusterRole", {
        metadata: { name: "view-role" },
        rules: [{ apiGroups: [""], resources: ["pods"], verbs: ["get", "list"] }],
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: ClusterRole");
    expect(result).toContain("name: view-role");
    expect(result).not.toContain("spec:");
  });

  test("ClusterRoleBinding is specless type", () => {
    const entities = new Map<string, any>();
    entities.set(
      "viewBinding",
      mockResource("K8s::Rbac::ClusterRoleBinding", {
        metadata: { name: "view-binding" },
        roleRef: { apiGroup: "rbac.authorization.k8s.io", kind: "ClusterRole", name: "view-role" },
        subjects: [{ kind: "ServiceAccount", name: "default", namespace: "default" }],
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: ClusterRoleBinding");
    expect(result).not.toContain("spec:");
  });

  test("StorageClass is specless type", () => {
    const entities = new Map<string, any>();
    entities.set(
      "gp3",
      mockResource("K8s::Storage::StorageClass", {
        metadata: { name: "gp3-encrypted" },
        provisioner: "ebs.csi.aws.com",
        parameters: { type: "gp3", encrypted: "true" },
        reclaimPolicy: "Delete",
        volumeBindingMode: "WaitForFirstConsumer",
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: StorageClass");
    expect(result).toContain("provisioner: ebs.csi.aws.com");
    expect(result).not.toContain("spec:");
  });

  test("APIService is specless type", () => {
    const entities = new Map<string, any>();
    entities.set(
      "metricsApi",
      mockResource("K8s::Admissionregistration::APIService", {
        metadata: { name: "v1beta1.metrics.k8s.io" },
        group: "metrics.k8s.io",
        version: "v1beta1",
        service: { name: "metrics-server", namespace: "kube-system" },
        groupPriorityMinimum: 100,
        versionPriority: 100,
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: APIService");
    expect(result).not.toContain("spec:");
  });

  test("multi-resource entities joined by ---", () => {
    const entities = new Map<string, any>();
    entities.set(
      "deploy",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "app" },
        spec: { replicas: 1 },
      }),
    );
    entities.set(
      "svc",
      mockResource("K8s::Core::Service", {
        metadata: { name: "app" },
        spec: { ports: [{ port: 80 }] },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("---");
    expect(result).toContain("kind: Deployment");
    expect(result).toContain("kind: Service");
  });

  test("default labels merged into metadata.labels", () => {
    const entities = new Map<string, any>();
    entities.set("labels", defaultLabels({ env: "prod" }));
    entities.set(
      "deploy",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "app" },
        spec: { replicas: 1 },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("env: prod");
  });

  test("default annotations merged into metadata.annotations", () => {
    const entities = new Map<string, any>();
    entities.set("annot", defaultAnnotations({ "note": "hello" }));
    entities.set(
      "deploy",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "app" },
        spec: { replicas: 1 },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("note: hello");
  });

  test("explicit labels override default labels", () => {
    const entities = new Map<string, any>();
    entities.set("labels", defaultLabels({ env: "dev" }));
    entities.set(
      "deploy",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "app", labels: { env: "prod" } },
        spec: { replicas: 1 },
      }),
    );

    const result = k8sSerializer.serialize(entities) as string;
    expect(result).toContain("env: prod");
    // Should not contain "dev" since explicit overrides
    const envLines = result.split("\n").filter((l: string) => l.includes("env:"));
    expect(envLines.every((l: string) => !l.includes("dev"))).toBe(true);
  });

  test("property entities skipped in output", () => {
    const entities = new Map<string, any>();
    entities.set("container", mockProperty("K8s::Core::Container", { name: "app" }));
    entities.set(
      "deploy",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "app" },
        spec: { replicas: 1 },
      }),
    );

    const result = k8sSerializer.serialize(entities) as string;
    expect(result).toContain("kind: Deployment");
    // Only one document — property entities should not appear as separate docs
    expect(result.split("---").length).toBeLessThanOrEqual(2);
  });

  test("DefaultLabels entities skipped in output", () => {
    const entities = new Map<string, any>();
    entities.set("labels", defaultLabels({ env: "prod" }));

    const result = k8sSerializer.serialize(entities);
    // defaultLabels alone should not produce any output
    expect(result).toBe("");
  });

  test("DefaultAnnotations entities skipped in output", () => {
    const entities = new Map<string, any>();
    entities.set("annotations", defaultAnnotations({ note: "hi" }));

    const result = k8sSerializer.serialize(entities);
    expect(result).toBe("");
  });

  test("Namespaces appear before other resources regardless of insertion order", () => {
    const entities = new Map<string, any>();
    // Insert Deployment first, then Namespace — Namespace should still come first in output
    entities.set(
      "deploy",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "app", namespace: "my-ns" },
        spec: { replicas: 1 },
      }),
    );
    entities.set(
      "ns",
      mockResource("K8s::Core::Namespace", {
        metadata: { name: "my-ns" },
      }),
    );

    const result = k8sSerializer.serialize(entities) as string;
    const docs = result.split("---");
    // First document should be the Namespace
    expect(docs[0]).toContain("kind: Namespace");
    expect(docs[0]).toContain("name: my-ns");
    // Second document should be the Deployment
    expect(docs[1]).toContain("kind: Deployment");
  });

  test("ConfigMap multiline data emits as | block scalar", () => {
    const entities = new Map<string, any>();
    const multilineConfig = "[SERVICE]\n    Flush 5\n    Log_Level info\n\n[INPUT]\n    Name tail\n";
    entities.set(
      "config",
      mockResource("K8s::Core::ConfigMap", {
        metadata: { name: "app-config" },
        data: { "fluent-bit.conf": multilineConfig },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: ConfigMap");
    // Must use | block scalar, not flatten to single line
    expect(result).toContain("fluent-bit.conf: |");
    // Content lines should be preserved (indented under the key)
    expect(result).toContain("[SERVICE]");
    expect(result).toContain("Flush 5");
    expect(result).toContain("[INPUT]");
    expect(result).toContain("Name tail");
    // Should NOT contain literal \n in the output
    expect(result).not.toContain("\\n");
  });

  test("key ordering: apiVersion, kind, metadata, spec, then rest", () => {
    const entities = new Map<string, any>();
    entities.set(
      "deploy",
      mockResource("K8s::Apps::Deployment", {
        metadata: { name: "app" },
        spec: { replicas: 1 },
      }),
    );

    const result = k8sSerializer.serialize(entities) as string;
    const lines = result.split("\n");
    const keyLines = lines.filter((l: string) => /^\w+:/.test(l));
    const keys = keyLines.map((l: string) => l.split(":")[0]);

    const apiIdx = keys.indexOf("apiVersion");
    const kindIdx = keys.indexOf("kind");
    const metaIdx = keys.indexOf("metadata");
    const specIdx = keys.indexOf("spec");

    expect(apiIdx).toBeLessThan(kindIdx);
    expect(kindIdx).toBeLessThan(metaIdx);
    expect(metaIdx).toBeLessThan(specIdx);
  });

  test("CRD-wrapper trick: props.apiVersion/kind override gvk-derived defaults", () => {
    // The Deployment-as-generic-CRD-wrapper pattern: pass arbitrary
    // apiVersion + kind in props and the serializer should respect them
    // (for emitting non-built-in CRDs through chant).
    const entities = new Map<string, any>();
    entities.set(
      "esoStore",
      mockResource("K8s::Apps::Deployment", {
        apiVersion: "external-secrets.io/v1beta1",
        kind: "ClusterSecretStore",
        metadata: { name: "my-store" },
        spec: { provider: { gcpsm: { projectID: "my-proj" } } },
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("apiVersion: external-secrets.io/v1beta1");
    expect(result).toContain("kind: ClusterSecretStore");
    expect(result).not.toContain("apiVersion: apps/v1");
    expect(result).not.toContain("kind: Deployment");
  });

  test("RBAC-shaped resources (rules/subjects/roleRef) stay at top level, not pushed under spec", () => {
    // ClusterRole / Role / RoleBinding / ClusterRoleBinding don't have a
    // spec field; their data is at the manifest root. When such a resource
    // arrives via the CRD-wrapper trick (no spec set in props), the
    // serializer used to dump rules/subjects/roleRef into a synthetic spec
    // — produced invalid manifests. Now they stay at top level.
    const entities = new Map<string, any>();
    entities.set(
      "viewerRole",
      mockResource("K8s::Apps::Deployment", {
        apiVersion: "rbac.authorization.k8s.io/v1",
        kind: "ClusterRole",
        metadata: { name: "viewer" },
        rules: [{ apiGroups: [""], resources: ["pods"], verbs: ["get", "list"] }],
      }),
    );

    const result = k8sSerializer.serialize(entities);
    expect(result).toContain("kind: ClusterRole");
    expect(result).toMatch(/^rules:/m);
    // The bug being guarded against: rules ending up under spec.
    expect(result).not.toMatch(/^spec:\s*\n\s+rules:/m);
  });
});

// ── Cross-resource references (#1493) ────────────────────────────────
//
// Kubernetes YAML has no deploy-time reference mechanism, so a reference has
// to be resolved before serialization or it means nothing. These used to
// serialize to the *logical* name, so a Deployment referencing its PVC emitted
// `claimName: pgClaim` and named a resource that does not exist — it applied
// cleanly and failed on the cluster.

function mockAttrRef(attribute: string, logicalName: string): any {
  // Shape isAttrRefLike() checks for: parent object, string attribute, and
  // _setLogicalName. Without the last one the walker treats it as a plain
  // object and the test silently asserts nothing.
  return {
    attribute,
    parent: { deref: () => undefined },
    _setLogicalName: () => {},
    getLogicalName: () => logicalName,
  };
}

describe("cross-resource references resolve at build time (#1493)", () => {
  test(".name resolves to the referenced resource's metadata.name", () => {
    const claim = mockResource("K8s::Core::PersistentVolumeClaim", {
      metadata: { name: "fountain-postgres", namespace: "fountain" },
      spec: { accessModes: ["ReadWriteOnce"] },
    });
    const dep = mockResource("K8s::Apps::Deployment", {
      metadata: { name: "fountain-postgres", namespace: "fountain" },
      spec: {
        template: {
          spec: {
            volumes: [
              { name: "data", persistentVolumeClaim: { claimName: mockAttrRef("name", "pgClaim") } },
            ],
          },
        },
      },
    });
    const yaml = k8sSerializer.serialize(new Map([["pgClaim", claim], ["pgDeployment", dep]]));
    expect(yaml).toContain("claimName: fountain-postgres");
    expect(yaml).not.toContain("claimName: pgClaim");
  });

  // A resource that declares no name gets one derived from its logical name.
  // A reference to it has to derive the SAME one or the two silently disagree.
  test(".name matches the derived name when the target declares none", () => {
    const claim = mockResource("K8s::Core::PersistentVolumeClaim", {
      spec: { accessModes: ["ReadWriteOnce"] },
    });
    const dep = mockResource("K8s::Apps::Deployment", {
      spec: { template: { spec: { volumes: [{ claimName: mockAttrRef("name", "pgClaim") }] } } },
    });
    const yaml = k8sSerializer.serialize(new Map([["pgClaim", claim], ["dep", dep]]));
    expect(yaml).toContain("name: pg-claim");
    expect(yaml).toContain("claimName: pg-claim");
  });

  test(".namespace resolves to the declared namespace", () => {
    const svc = mockResource("K8s::Core::Service", {
      metadata: { name: "fountain", namespace: "fountain" },
    });
    const dep = mockResource("K8s::Apps::Deployment", {
      metadata: { name: "app" },
      spec: { host: mockAttrRef("namespace", "service") },
    });
    const yaml = k8sSerializer.serialize(new Map([["service", svc], ["dep", dep]]));
    expect(yaml).toContain("host: fountain");
  });

  // A UID is assigned by the API server at admission, so emitting any
  // build-time string for it would be a fabrication.
  test(".uid is refused rather than fabricated", () => {
    const svc = mockResource("K8s::Core::Service", { metadata: { name: "fountain" } });
    const dep = mockResource("K8s::Apps::Deployment", {
      spec: { ownerRef: mockAttrRef("uid", "service") },
    });
    expect(() => k8sSerializer.serialize(new Map([["service", svc], ["dep", dep]]))).toThrow(
      /assigned by the API server/,
    );
  });

  test("an unresolvable namespace says what to set rather than emitting a wrong one", () => {
    const svc = mockResource("K8s::Core::Service", { metadata: { name: "fountain" } });
    const dep = mockResource("K8s::Apps::Deployment", {
      spec: { ns: mockAttrRef("namespace", "service") },
    });
    expect(() => k8sSerializer.serialize(new Map([["service", svc], ["dep", dep]]))).toThrow(
      /declares no metadata.namespace/,
    );
  });

  test("an attribute k8s cannot express is refused with the reason", () => {
    const svc = mockResource("K8s::Core::Service", { metadata: { name: "fountain" } });
    const dep = mockResource("K8s::Apps::Deployment", {
      spec: { x: mockAttrRef("clusterIP", "service") },
    });
    expect(() => k8sSerializer.serialize(new Map([["service", svc], ["dep", dep]]))).toThrow(
      /resolves .name and .namespace/,
    );
  });
});
