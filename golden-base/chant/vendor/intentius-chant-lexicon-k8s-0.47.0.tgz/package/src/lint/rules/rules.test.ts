import { describe, test, expect } from "vitest";
import { hardcodedNamespaceRule } from "./hardcoded-namespace";
import { latestImageTagRule } from "./latest-image-tag";
import { missingResourceLimitsRule } from "./missing-resource-limits";
import { argoAutomatedPruneRule } from "./argo-automated-prune";
import { argoAppSetSingleProjectRule } from "./argo-appset-single-project";
import { fluxSourceRefPinRule } from "./flux-source-ref-pin";
import * as ts from "typescript";

function createContext(code: string) {
  const sourceFile = ts.createSourceFile(
    "test.ts",
    code,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
  return { sourceFile } as any;
}

describe("WK8001: Hardcoded Namespace", () => {
  test("rule metadata", () => {
    expect(hardcodedNamespaceRule.id).toBe("WK8001");
    expect(hardcodedNamespaceRule.severity).toBe("warning");
    expect(hardcodedNamespaceRule.category).toBe("correctness");
  });

  test("flags namespace: 'production' string literal", () => {
    const ctx = createContext(
      `new Deployment({ metadata: { namespace: "production" } });`,
    );
    const diags = hardcodedNamespaceRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].ruleId).toBe("WK8001");
    expect(diags[0].message).toContain("production");
  });

  test("flags namespace: 'default' string literal", () => {
    const ctx = createContext(
      `new Deployment({ metadata: { namespace: "default" } });`,
    );
    const diags = hardcodedNamespaceRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].message).toContain("default");
  });

  test("does NOT flag namespace: myVar (variable reference)", () => {
    const ctx = createContext(
      `const ns = "production"; new Deployment({ metadata: { namespace: ns } });`,
    );
    const diags = hardcodedNamespaceRule.check(ctx);
    // Only the string literal assignment to `namespace` key counts
    // Variable references should not be flagged
    const nsFlags = diags.filter((d) => d.ruleId === "WK8001");
    expect(nsFlags.length).toBe(0);
  });

  test("does NOT flag empty namespace string", () => {
    const ctx = createContext(
      `new Deployment({ metadata: { namespace: "" } });`,
    );
    const diags = hardcodedNamespaceRule.check(ctx);
    expect(diags.length).toBe(0);
  });

  test("flags multiple hardcoded namespaces", () => {
    const ctx = createContext(`
      const a = new Deployment({ metadata: { namespace: "staging" } });
      const b = new Service({ metadata: { namespace: "prod" } });
    `);
    const diags = hardcodedNamespaceRule.check(ctx);
    expect(diags.length).toBe(2);
  });
});

// ── WK8002: Latest Image Tag ────────────────────────────────────────

describe("WK8002: Latest Image Tag", () => {
  test("rule metadata", () => {
    expect(latestImageTagRule.id).toBe("WK8002");
    expect(latestImageTagRule.severity).toBe("warning");
    expect(latestImageTagRule.category).toBe("security");
  });

  test("flags image: 'nginx:latest'", () => {
    const ctx = createContext(
      `new Deployment({ spec: { template: { spec: { containers: [{ name: "app", image: "nginx:latest" }] } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].ruleId).toBe("WK8002");
    expect(diags[0].message).toContain(":latest");
  });

  test("flags untagged image: 'nginx'", () => {
    const ctx = createContext(
      `new Deployment({ spec: { template: { spec: { containers: [{ name: "app", image: "nginx" }] } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].ruleId).toBe("WK8002");
    expect(diags[0].message).toContain("no tag");
  });

  test("flags registry-prefixed untagged image: 'ghcr.io/org/app'", () => {
    const ctx = createContext(
      `new Deployment({ spec: { template: { spec: { containers: [{ name: "app", image: "ghcr.io/org/app" }] } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(1);
  });

  test("does NOT flag explicitly tagged image: 'nginx:1.25'", () => {
    const ctx = createContext(
      `new Deployment({ spec: { template: { spec: { containers: [{ name: "app", image: "nginx:1.25" }] } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(0);
  });

  test("does NOT flag image with digest", () => {
    const ctx = createContext(
      `new Deployment({ spec: { template: { spec: { containers: [{ name: "app", image: "nginx@sha256:abc123" }] } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(0);
  });

  test("flags :latest in StatefulSet", () => {
    const ctx = createContext(
      `new StatefulSet({ spec: { template: { spec: { containers: [{ name: "db", image: "postgres:latest" }] } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(1);
  });

  test("flags :latest in DaemonSet", () => {
    const ctx = createContext(
      `new DaemonSet({ spec: { template: { spec: { containers: [{ name: "agent", image: "datadog:latest" }] } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(1);
  });

  test("flags :latest in CronJob", () => {
    const ctx = createContext(
      `new CronJob({ spec: { jobTemplate: { spec: { template: { spec: { containers: [{ name: "job", image: "worker:latest" }] } } } } } });`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(1);
  });

  test("does NOT flag image property outside workload constructor", () => {
    const ctx = createContext(
      `const config = { image: "nginx:latest" };`,
    );
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(0);
  });

  test("flags multiple containers with bad images", () => {
    const ctx = createContext(`
      new Deployment({
        spec: {
          template: {
            spec: {
              containers: [
                { name: "app", image: "nginx:latest" },
                { name: "sidecar", image: "envoy" },
              ],
            },
          },
        },
      });
    `);
    const diags = latestImageTagRule.check(ctx);
    expect(diags.length).toBe(2);
  });
});

// ── WK8003: Missing Resource Limits ─────────────────────────────────

describe("WK8003: Missing Resource Limits", () => {
  test("rule metadata", () => {
    expect(missingResourceLimitsRule.id).toBe("WK8003");
    expect(missingResourceLimitsRule.severity).toBe("warning");
    expect(missingResourceLimitsRule.category).toBe("correctness");
  });

  test("flags container without resources property", () => {
    const ctx = createContext(
      `new Deployment({ spec: { template: { spec: { containers: [{ name: "app", image: "app:1.0" }] } } } });`,
    );
    const diags = missingResourceLimitsRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].ruleId).toBe("WK8003");
    expect(diags[0].message).toContain("app");
    expect(diags[0].message).toContain("resource limits");
  });

  test("does NOT flag container with resources property", () => {
    const ctx = createContext(
      `new Deployment({ spec: { template: { spec: { containers: [{ name: "app", image: "app:1.0", resources: { limits: { cpu: "500m", memory: "256Mi" } } }] } } } });`,
    );
    const diags = missingResourceLimitsRule.check(ctx);
    expect(diags.length).toBe(0);
  });

  test("flags container in StatefulSet", () => {
    const ctx = createContext(
      `new StatefulSet({ spec: { template: { spec: { containers: [{ name: "db", image: "postgres:15" }] } } } });`,
    );
    const diags = missingResourceLimitsRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].message).toContain("db");
  });

  test("flags only containers without resources in mixed array", () => {
    const ctx = createContext(`
      new Deployment({
        spec: {
          template: {
            spec: {
              containers: [
                { name: "app", image: "app:1.0", resources: { limits: { cpu: "1" } } },
                { name: "sidecar", image: "envoy:1.0" },
              ],
            },
          },
        },
      });
    `);
    const diags = missingResourceLimitsRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].message).toContain("sidecar");
  });

  test("does NOT flag outside workload constructor", () => {
    const ctx = createContext(
      `const containers = [{ name: "app", image: "app:1.0" }];`,
    );
    const diags = missingResourceLimitsRule.check(ctx);
    expect(diags.length).toBe(0);
  });

  test("flags multiple containers without resources", () => {
    const ctx = createContext(`
      new Deployment({
        spec: {
          template: {
            spec: {
              containers: [
                { name: "web", image: "nginx:1.25" },
                { name: "api", image: "api:2.0" },
              ],
            },
          },
        },
      });
    `);
    const diags = missingResourceLimitsRule.check(ctx);
    expect(diags.length).toBe(2);
  });
});

describe("ARGO001: Production Application automated prune", () => {
  test("rule metadata", () => {
    expect(argoAutomatedPruneRule.id).toBe("ARGO001");
    expect(argoAutomatedPruneRule.severity).toBe("warning");
    expect(argoAutomatedPruneRule.category).toBe("correctness");
  });

  test("flags prod Application with automated prune and no override", () => {
    const ctx = createContext(`
      new Application({
        metadata: { name: "api-prod" },
        spec: { syncPolicy: { automated: { prune: true, selfHeal: true } } },
      });
    `);
    const diags = argoAutomatedPruneRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].ruleId).toBe("ARGO001");
    expect(diags[0].message).toContain("api-prod");
  });

  test("does NOT flag when prune is false", () => {
    const ctx = createContext(`
      new Application({
        metadata: { name: "api-prod" },
        spec: { syncPolicy: { automated: { prune: false } } },
      });
    `);
    expect(argoAutomatedPruneRule.check(ctx).length).toBe(0);
  });

  test("does NOT flag prod Application carrying the allow-prune override annotation", () => {
    const ctx = createContext(`
      new Application({
        metadata: { name: "api-prod", annotations: { "argocd.chant.dev/allow-prune": "true" } },
        spec: { syncPolicy: { automated: { prune: true } } },
      });
    `);
    expect(argoAutomatedPruneRule.check(ctx).length).toBe(0);
  });

  test("does NOT flag a non-prod Application with automated prune", () => {
    const ctx = createContext(`
      new Application({
        metadata: { name: "api-staging" },
        spec: { syncPolicy: { automated: { prune: true } } },
      });
    `);
    expect(argoAutomatedPruneRule.check(ctx).length).toBe(0);
  });

  test("infers prod from destination namespace", () => {
    const ctx = createContext(`
      new Application({
        metadata: { name: "api" },
        spec: {
          destination: { namespace: "production" },
          syncPolicy: { automated: { prune: true } },
        },
      });
    `);
    expect(argoAutomatedPruneRule.check(ctx).length).toBe(1);
  });
});

describe("ARGO004: ApplicationSet single AppProject", () => {
  test("rule metadata", () => {
    expect(argoAppSetSingleProjectRule.id).toBe("ARGO004");
    expect(argoAppSetSingleProjectRule.severity).toBe("warning");
    expect(argoAppSetSingleProjectRule.category).toBe("correctness");
  });

  test("does NOT flag a static single project", () => {
    const ctx = createContext(`
      new ApplicationSet({
        metadata: { name: "team-a-apps" },
        spec: { template: { spec: { project: "team-a", repoURL: "https://example.com/repo" } } },
      });
    `);
    expect(argoAppSetSingleProjectRule.check(ctx).length).toBe(0);
  });

  test("flags a missing template project", () => {
    const ctx = createContext(`
      new ApplicationSet({
        metadata: { name: "team-a-apps" },
        spec: { template: { spec: { repoURL: "https://example.com/repo" } } },
      });
    `);
    const diags = argoAppSetSingleProjectRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].ruleId).toBe("ARGO004");
    expect(diags[0].message).toContain("no spec.project");
  });

  test("flags a templated (generator placeholder) project", () => {
    const ctx = createContext(`
      new ApplicationSet({
        metadata: { name: "per-cluster" },
        spec: { template: { spec: { project: "{{path.basename}}" } } },
      });
    `);
    const diags = argoAppSetSingleProjectRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].message).toContain("placeholder");
  });
});

describe("FLUX001: GitRepository must pin spec.ref", () => {
  test("rule metadata", () => {
    expect(fluxSourceRefPinRule.id).toBe("FLUX001");
    expect(fluxSourceRefPinRule.severity).toBe("warning");
    expect(fluxSourceRefPinRule.category).toBe("correctness");
  });

  test("flags a GitRepository with a url but no ref", () => {
    const ctx = createContext(`
      new GitRepository({
        metadata: { name: "home-chant" },
        spec: { interval: "5m", url: "https://github.com/jhgaylor/home-chant" },
      });
    `);
    const diags = fluxSourceRefPinRule.check(ctx);
    expect(diags.length).toBe(1);
    expect(diags[0].ruleId).toBe("FLUX001");
    expect(diags[0].message).toContain("home-chant");
    expect(diags[0].message).toContain("master");
  });

  test("does NOT flag a branch pin", () => {
    const ctx = createContext(`
      new GitRepository({
        metadata: { name: "home-chant" },
        spec: { url: "https://github.com/jhgaylor/home-chant", ref: { branch: "main" } },
      });
    `);
    expect(fluxSourceRefPinRule.check(ctx).length).toBe(0);
  });

  test("does NOT flag a tag pin", () => {
    const ctx = createContext(`
      new GitRepository({
        metadata: { name: "infra" },
        spec: { url: "https://example.com/infra", ref: { tag: "v1.2.3" } },
      });
    `);
    expect(fluxSourceRefPinRule.check(ctx).length).toBe(0);
  });

  test("skips a GitRepository with no inspectable spec literal", () => {
    const ctx = createContext(`
      const spec = buildSpec();
      new GitRepository({ metadata: { name: "dynamic" }, spec });
    `);
    expect(fluxSourceRefPinRule.check(ctx).length).toBe(0);
  });
});
