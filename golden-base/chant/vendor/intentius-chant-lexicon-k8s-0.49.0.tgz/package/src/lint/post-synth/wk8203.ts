/**
 * WK8203: ReadOnlyRootFilesystem Recommended
 *
 * Containers should set securityContext.readOnlyRootFilesystem to true.
 * A read-only root filesystem prevents runtime modification of the container
 * image, reducing the attack surface.
 */

import type { PostSynthCheck, PostSynthContext, PostSynthDiagnostic } from "@intentius/chant/lint/post-synth";
import { docsToManifests, extractContainers, WORKLOAD_KINDS } from "./k8s-helpers";

export const wk8203: PostSynthCheck = {
  id: "WK8203",
  description: "ReadOnlyRootFilesystem recommended — prevents runtime modification of the container image",

  check(ctx: PostSynthContext): PostSynthDiagnostic[] {
    const diagnostics: PostSynthDiagnostic[] = [];

    for (const manifest of docsToManifests(ctx)) {
      if (!manifest.kind || !WORKLOAD_KINDS.has(manifest.kind)) continue;

      const containers = extractContainers(manifest);
      const resourceName = manifest.metadata?.name ?? manifest.kind;

      for (const container of containers) {
        const secCtx = container.securityContext;
        if (!secCtx || secCtx.readOnlyRootFilesystem !== true) {
          diagnostics.push({
            checkId: "WK8203",
            severity: "warning",
            message: `Container "${container.name ?? "(unnamed)"}" in ${manifest.kind} "${resourceName}" does not set readOnlyRootFilesystem: true — set it to reduce the attack surface`,
            entity: resourceName,
            lexicon: "k8s",
          });
        }
      }
    }

    return diagnostics;
  },
};
