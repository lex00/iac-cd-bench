// Serializer
export { k8sSerializer } from "./serializer";

// Plugin
export { k8sPlugin } from "./plugin";

// Typed Op step-builder wrappers (chant #1288 Stage 2) — kubectlApply/
// waitForReady/ensureSecret — are deliberately NOT re-exported here: their
// types derive from the activities' own *Args interfaces, which name the API
// client and therefore sit behind the #1074 dynamic-import boundary this
// entry point must never reach, even type-only
// (examples/k8s-client-boundary.test.ts). Import them via the subpath
// `@intentius/chant-lexicon-k8s/op/builders`, the same way workers import
// `@intentius/chant-lexicon-k8s/op/activities`.

// The capability plugin core's loader discovers on this package (#1495 piece 2)
// — the kubectl-apply leaf a component composes, the way aws contributes
// cfn-deploy.
export { k8sCapabilityPlugin, K8S_VERB_FAMILIES } from "./components/capability-plugin";
export { kubectlApplyCapability, createKubectlApplyCapability, type KubectlApplyInput } from "./components/kubectl-apply";
export { kustomizeApplyCapability, createKustomizeApplyCapability, type KustomizeApplyInput } from "./components/kustomize-apply";

// Default labels & annotations
export { defaultLabels, defaultAnnotations, isDefaultLabels, isDefaultAnnotations } from "./default-labels";
export { DEFAULT_LABELS_MARKER, DEFAULT_ANNOTATIONS_MARKER } from "./default-labels";

// Variables / label constants
export { K8sLabels, K8sAnnotations } from "./variables";

// Generated-once secret marker (#1830) — constants only; the store adapter
// itself lives at the `/secret-store` subpath, off the build path (#1074).
export { GENERATED_ONCE_LABEL_KEY, GENERATED_ONCE_LABEL_VALUE, isGeneratedOnce } from "./secret-labels";

// MicroTime helpers — see micro-time.ts for why this exists.
export { microTime, isMicroTimeFormatted } from "./micro-time";

// Generated entities — export everything from generated index
// After running `chant generate`, this re-exports all K8s resource classes
export * from "./generated/index";

// Composites
export {
  WebApp, StatefulApp, CronWorkload, AutoscaledService, WorkerPool, NamespaceEnv, NodeAgent,
  BatchJob, SecureIngress, ConfiguredApp, SidecarApp, MonitoredService, NetworkIsolatedApp,
  IrsaServiceAccount, AlbIngress, EbsStorageClass, EfsStorageClass, FluentBitAgent, ExternalDnsAgent, AdotCollector,
  MetricsServer, WorkloadIdentityServiceAccount, GcePdStorageClass, FilestoreStorageClass, GkeGateway, ConfigConnectorContext,
  GceIngress, CockroachDbCluster, CockroachDbRegionStack,
  RayCluster, RayJob, RayService,
  ArgoAppFor, ArgoAppSetForRegions, registerArgoCluster,
  FluxGitSource, FluxAppFor,
  AgicIngress, AzureDiskStorageClass, AzureFileStorageClass, AzureMonitorCollector,
  AksWorkloadIdentityServiceAccount,
  GkeFluentBitAgent, GkeOtelCollector, GkeExternalDnsAgent, AksExternalDnsAgent,
  Model, resolveModelStorageUri,
  OperatorStack, deriveHostVerbClass, DEFAULT_RESOURCE_RULES,
} from "./composites/index";
export type {
  WebAppProps, WebAppResult, StatefulAppProps, StatefulAppResult, CronWorkloadProps, CronWorkloadResult,
  AutoscaledServiceProps, AutoscaledServiceResult, WorkerPoolProps, WorkerPoolResult,
  NamespaceEnvProps, NamespaceEnvResult, NodeAgentProps, NodeAgentResult,
  BatchJobProps, BatchJobResult, SecureIngressProps, SecureIngressResult,
  ConfiguredAppProps, ConfiguredAppResult, SidecarAppProps, SidecarAppResult,
  MonitoredServiceProps, MonitoredServiceResult, NetworkIsolatedAppProps, NetworkIsolatedAppResult,
  IrsaServiceAccountProps, IrsaServiceAccountResult, AlbIngressProps, AlbIngressResult,
  EbsStorageClassProps, EbsStorageClassResult, EfsStorageClassProps, EfsStorageClassResult,
  FluentBitAgentProps, FluentBitAgentResult, ExternalDnsAgentProps, ExternalDnsAgentResult,
  AdotCollectorProps, AdotCollectorResult,
  MetricsServerProps, MetricsServerResult,
  WorkloadIdentityServiceAccountProps, WorkloadIdentityServiceAccountResult,
  GcePdStorageClassProps, GcePdStorageClassResult,
  FilestoreStorageClassProps, FilestoreStorageClassResult,
  GkeGatewayProps, GkeGatewayResult,
  ConfigConnectorContextProps, ConfigConnectorContextResult,
  GceIngressProps, GceIngressResult, CockroachDbClusterProps, CockroachDbClusterResult,
  CockroachDbRegionStackConfig, CockroachDbRegionCockroachConfig, CockroachDbRegionTlsConfig,
  RayClusterProps, RayClusterResult, RayClusterSpec, ResourceSpec, HeadGroupSpec, WorkerGroupSpec,
  RayJobProps, RayJobResult,
  RayServiceProps, RayServiceResult,
  ArgoDestination, ArgoSyncPolicy,
  ArgoAppForOptions, ArgoAppForResult,
  ArgoRegionTarget, ArgoAppSetForRegionsOptions, ArgoAppSetForRegionsResult,
  RegisterArgoClusterOptions, RegisterArgoClusterResult,
  FluxSourceKind, FluxSourceRef,
  FluxGitSourceOptions, FluxGitSourceResult,
  FluxAppForOptions, FluxAppForResult,
  AgicIngressProps, AgicIngressResult,
  AzureDiskStorageClassProps, AzureDiskStorageClassResult,
  AzureFileStorageClassProps, AzureFileStorageClassResult,
  AzureMonitorCollectorProps, AzureMonitorCollectorResult,
  AksWorkloadIdentityServiceAccountProps, AksWorkloadIdentityServiceAccountResult,
  GkeFluentBitAgentProps, GkeFluentBitAgentResult,
  GkeOtelCollectorProps, GkeOtelCollectorResult,
  GkeExternalDnsAgentProps, GkeExternalDnsAgentResult,
  AksExternalDnsAgentProps, AksExternalDnsAgentResult,
  ModelSource, ModelProps, ModelResult,
  OperatorDial, OperatorRbacResourceRule, OperatorStackConvergeHost, OperatorStackConfig, OperatorStackResult,
} from "./composites/index";

// RBAC verb constants
export * from "./actions/index";

// Spec utilities (for tooling)
export { fetchK8sSchema, fetchSchemas, K8S_SCHEMA_VERSION } from "./spec/fetch";
export { parseK8sSwagger, k8sShortName, k8sServiceName, gvkToTypeName, gvkToApiVersion } from "./spec/parse";
export type { K8sParseResult, ParsedResource, ParsedProperty, ParsedPropertyType, ParsedEnum, GroupVersionKind } from "./spec/parse";

// Code generation pipeline
export { generate, writeGeneratedFiles } from "./codegen/generate";
export { packageLexicon } from "./codegen/package";
export type { PackageOptions, PackageResult } from "./codegen/package";

// CRD framework
export type { CRDSource, CRDSpec } from "./crd/types";
export { parseCRD, parseCRDSpec } from "./crd/parser";
export { loadCRDs, loadMultipleCRDs } from "./crd/loader";

// Environment → cluster binding config shape (chant #1100)
export type { K8sChantConfig, K8sClusterProfile } from "./config";
